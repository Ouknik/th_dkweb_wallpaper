import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:th_dkweb/Controller/home_controller.dart';
import 'package:th_dkweb/constant.dart';

import 'catagory_items.dart';

class CategoryView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: PrimarColor,
      appBar: AppBar(
        backgroundColor: PrimarColor,
        centerTitle: false,
        elevation: 0.0,
        title: Text('Categories',
            style: TextStyle(
              color: Colors.black,
            )),
      ),
      body: GetBuilder<HomeController>(
        builder: (controller) => controller.loding.value == true
            ? Center(child: CircularProgressIndicator())
            : GridView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: EdgeInsets.all(15),
                itemCount: controller.categoryModel.length,
                // itemBuilder: (BuildContext context, int index) {
                //   return SizedBox(
                //     height: 10,
                //   );
                // },

                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 202,
                    mainAxisExtent: MediaQuery.of(context).size.width * 0.41,
                    childAspectRatio: 3 / 2,
                    crossAxisSpacing: 2,
                    mainAxisSpacing: 2),

                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      InkWell(
                        child: Container(
                          height: 140,
                          width: w,
                          decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10),
                              ),
                              image: DecorationImage(
                                  image: NetworkImage(
                                      controller.categoryModel[index].image),
                                  fit: BoxFit.cover)),
                        ),
                        onTap: () {
                          controller.getCategoryItem(
                              controller.categoryModel[index].nameCategory);
                          Get.to(CategoryItems(
                              controller.categoryModel[index].nameCategory));
                          // CatagoryItem(
                          //             title: db.categories[index]['name'],
                          //            selectedCatagory: db.categories[index]['name'],
                          //         )
                        },
                      ),
                      Container(
                          width: w,
                          color: Colors.green.shade300,
                          child: Center(
                              child: Text(
                                  controller.categoryModel[index].nameCategory,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w600)))),
                    ],
                  );
                },
              ),
      ),
    );
  }
}
