import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:th_dkweb/Controller/home_controller.dart';
import 'package:th_dkweb/Model/fav_caetegory_item.dart';
import 'package:th_dkweb/constant.dart';
import 'utils/extenstion.dart';

class FavoritePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: HexColor.fromHex("#F2F2FD"), //F2F2FD,
        body: GetBuilder<HomeController>(
            builder: (controller) => controller.cartProductsModel.length == 0
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Container(
                          child: Image.asset('lib/images/favorite.gif'),
                        ),
                      ),
                      Text(
                        'Favorites is empty',
                        style: (TextStyle(
                            color: HexColor.fromHex("#9263E9"), fontSize: 20)),
                      )
                    ],
                  )
                : ListView.builder(
                    itemCount: controller.cartProductsModel.length,
                    itemBuilder: (context, i) {
                      return Card(
                        color: PrimarColor,
                        child: GestureDetector(
                          onTap: () {},
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Image.network(
                                controller.cartProductsModel[i].image_url
                                    .toString(),
                                width: 100,
                                height: 100,
                              ),
                              Column(
                                children: [
                                  Text(
                                    controller.cartProductsModel[i].category
                                        .toString(),
                                    style: TextStyle(color: Colors.black),
                                  ),
                                  const Text(
                                    "#Wallpaper",
                                    style: TextStyle(color: Colors.black26),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      controller.removeFAv(FavCategoryItem(
                                          category: controller
                                              .cartProductsModel[i].category,
                                          image_url: controller
                                              .cartProductsModel[i].image_url,
                                          loves: controller
                                              .cartProductsModel[i].loves,
                                          timestamp: controller
                                              .cartProductsModel[i].timestamp));
                                    },
                                    icon: Icon(Icons.delete),
                                    color: Colors.black38,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    })));
  }
}
