import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:th_dkweb/Controller/home_controller.dart';

import '../details.dart';
import 'cached_image.dart';
import 'extenstion.dart';

class NewItems extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (controller) => Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.3,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.NewItem.length,
          itemBuilder: (context, index) {
            return Container(
              width: MediaQuery.of(context).size.width * 0.3,
              height: MediaQuery.of(context).size.height * 0.3,
              child: GestureDetector(
                onTap: () {
                  Get.to(DetailsPage(
                    model: controller.NewItem[index],
                  ));
                },
                child: Stack(
                  children: <Widget>[
                    Hero(
                        tag: 'new$index',
                        child:
                            cachedImage(controller.NewItem[index].image_url)),
                    Positioned(
                      bottom: MediaQuery.of(context).size.height * 0.01,
                      left: MediaQuery.of(context).size.width * 0.01,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            controller.NewItem[index].category,
                            style: TextStyle(
                                color: HexColor.fromHex("#9263E9"),
                                fontSize: 18),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
