//class PopularItems extends
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:th_dkweb/Controller/home_controller.dart';
import 'package:th_dkweb/View/details.dart';

import 'extenstion.dart';

class PopularItems extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (controller) => SingleChildScrollView(
        child: GridView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 202,
                mainAxisExtent: MediaQuery.of(context).size.width * 0.48,
                childAspectRatio: 3 / 2,
                crossAxisSpacing: 2,
                mainAxisSpacing: 2),
            //  controller: controller,
            itemCount: controller.NewItem.length,
            itemBuilder: (BuildContext context, int index) {
              return controller.NewItem.length == 0
                  ? CircularProgressIndicator(
                      color: Colors.black,
                    )
                  : Container(
                      width: MediaQuery.of(context).size.width * 0.3,
                      height: MediaQuery.of(context).size.height * 0.3,
                      child: GestureDetector(
                        onTap: () {
                          Get.to(DetailsPage(model: controller.NewItem[index]));
                        },
                        child: Stack(
                          children: <Widget>[
                            Hero(
                                tag: 'new$index',
                                child: Image.network(
                                    controller.NewItem[index].image_url)),
                            Positioned(
                              bottom: MediaQuery.of(context).size.height * 0.01,
                              left: MediaQuery.of(context).size.width * 0.01,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    controller.NewItem[index].category,
                                    style: TextStyle(
                                        color: HexColor.fromHex("#9263E9"),
                                        fontSize: 18),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
            }),
      ),
    );
  }
}
