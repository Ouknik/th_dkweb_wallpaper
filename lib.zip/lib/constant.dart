import 'package:flutter/material.dart';

import 'View/utils/extenstion.dart';

final Color PrimarColor = HexColor.fromHex("#F2F2FD");

final String tableFavwall = 'favwall';
final String columncategory = 'category';
final String columnimage_url = 'image_url';
final String columnloves = 'loves';
final String columntimestamp = 'timestamp';
