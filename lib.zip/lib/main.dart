import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:th_dkweb/View/home_view.dart';

import 'Controller/data_bloc.dart';
import 'Controller/home_controller.dart';
import 'View/button_navigator_view.dart';
import 'View/category.dart';
import 'View/splash_scren.dart';
import 'helpear/bindings.dart';

Future<void> main() async {
  await FlutterDownloader.initialize(debug: true);
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(HomeController());
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<DataBloc>(
          create: (context) => DataBloc(),
        )
      ],
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        initialBinding: Binding(),
        home: GetBuilder<HomeController>(builder: (contrller) => SplashScren()),
      ),
    );
  }
}
